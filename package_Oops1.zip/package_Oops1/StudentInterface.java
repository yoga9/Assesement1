package package_Oops1;

public interface StudentInterface {
 
	      void details();
	      void display();
}

 class Demo implements StudentInterface{

	@Override
	public void details() {
		// TODO Auto-generated method stub
		System.out.println("student A shown");
	}

	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("student A displayed");
		
	}
	
 class Demo1 implements StudentInterface{

	@Override
	public void details() {
		// TODO Auto-generated method stub
		System.out.println("student B shown");
	}

	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("student B displayed");
	}
	
}
	
	public static void main(String args[]) {
		 
		Demo obj = new Demo();
		obj.details();
		obj.display();
		
		Demo1 obj1= new Demo1();
		obj1.details();
		obj1.display();
		
	}
}

