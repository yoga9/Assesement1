package package_Oops1;          //Abstract class

public abstract class AbstractDemo {
	
	 abstract public void show();
	 
	 public void myShow() {
		 
		 System.out.println("shown");
		 
		 }
	 public class Demo extends AbstractDemo {

		@Override
		public void show() {
			// TODO Auto-generated method stub
			System.out.println(" Abstract shown");
		}
		 
	public static void main(String args[]) {
		
		Demo obj  = new Demo();
		obj.show();
		//obj.myShown();
		
		
	}
		
	}
	 

}
