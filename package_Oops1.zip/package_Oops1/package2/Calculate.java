package package2;

import package1.*;

class Calculate extends Add{
	
	public static void main(String args[]) {
		
		Calculate obj = new Calculate();
		System.out.println(obj.addition(5,5));
		
	}

}
