package package_Oops1;

public class MethodOverloading {
	
	public void shapes(int size)
	{
		System.out.println(size);
	}
	
    public void shapes(String name, char size)  {
    	System.out.println(name+ " "+size);
    }
    
    public void shapes(int size, String name)  {
    	System.out.println(size+" "+name);
    }

    public void shapes(double size, char name)  {
    	System.out.println(size+" "+name);
    }


	
	public static void main(String[] args) {
		
		MethodOverloading m = new MethodOverloading();
		m.shapes(5);
		m.shapes("square", 'A');
		m.shapes(6, "Rectangle");
		m.shapes(5.5,'B');
		
		
	}
}
