package package_Oops1;       //MethodOverriding

	 
     class Fruits{
		
		public void display() {
		System.out.println("Good to Health");
		
		}
	}
		
	 class Apple extends Fruits{
		
		public void display() {
		System.out.println("Contain High amount of Vitamin C");
		}
	 
	
	
		
    public static void main(String args[]) {
    	
       
	
	   Fruits f= new Fruits();
	   f.display();
	 
	   Fruits f1= new Apple();
	   f1.display();
	   
	   Apple a= new Apple();
	   a.display();
	   
	 }
}


