package package_Oops1;        //Inheritance

	
 class Parent
{
		 void display() {
		
		System.out.println("First");
		
		}
}
	  class Child extends Parent
	{
		 void display1() {
			System.out.println("Second");
		}
	}
		
	 class SubChild extends Parent
	{
			 void display2() {
				System.out.println("Third");
			}
	
	 
	
		
	public static void main(String[] args) {
		
	
		Parent p = new Parent();
		Child c = new Child();
		SubChild s = new SubChild();
		
		p.display();
		c.display();
		c.display1();
		s.display();
		s.display2();
		
		
	}}
	 


	
