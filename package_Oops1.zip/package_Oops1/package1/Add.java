package package1;

public class Add {
	protected int addition(int a,int b) {
		return a+b;
	}

}
